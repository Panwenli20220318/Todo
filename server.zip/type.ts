export type ListItem = {
    id: string;
    content: string;
    createTime: number;
    status: number;
    isDone: boolean
};

export type AddItemResponse = {
    id?: string;
    msg: string;
    status: boolean;
}