import { v4 } from 'uuid'
import {ListItem, AddItemResponse} from './type'
const fs = require('fs')
const path = require('path')

// 异步添加数据并保存到list.json中
export const addItem = async (content: string):Promise<AddItemResponse> => {
    const list = await getList()
    const id = v4()
    const item: ListItem = {
        id,
        content,
        createTime: Date.now(),
        status: 1,
        isDone: false
    }
    let final = Object.assign(list, {[id]: item})
    return new Promise((resolve) => {
        fs.writeFile(path.join(__dirname, './list.json'), JSON.stringify(final), (err: any) => {
            if (err) {                
                resolve({msg: err, status: false})
            } else {
                resolve({msg: 'ok', id: item.id, status: true})
            }
        })
    })
}


// 异步获取list.json中的数据
export const getList = async ():Promise<Record<string, ListItem>> => {
    return new Promise((resolve, reject) => {
        fs.readFile(path.join(__dirname, './list.json'), (err: any, data: any) => {
            if (err) {
                reject(err)
            } else {
                resolve(JSON.parse(data.toString()))
            }
        })
    })
}

// 根据id异步删除list.json中的数据,键值都删除
export const deleteItem = async (id: string):Promise<string> => {
    const list = await getList()
    const needDeleteItem = list[id]
    if(needDeleteItem) {
        needDeleteItem.status = 0
        const final = Object.assign(list, {[id]: needDeleteItem})
        return new Promise((resolve, reject) => {
            fs.writeFile(path.join(__dirname, './list.json'), JSON.stringify(final), (err: any) => {
                if (err) {
                    reject('err')
                } else {
                    resolve('ok')
                }
            })
        })
    } else {
        return Promise.reject('无此记录，无法删除')
    }
}

// 根据id异步修改list.json中的isDone
export const changeData = async (id: string):Promise<string> => {
    const list = await getList()
    const needChangeItem = list[id]
    if(needChangeItem?.status === 0) {
        return Promise.reject('记录已被删除，无法修改')
    }
    if(!needChangeItem) {
        return Promise.reject('无此记录，无法修改')
    }
    needChangeItem.isDone = !needChangeItem.isDone
    const final = Object.assign(list, {[id]: needChangeItem})
    return new Promise((resolve, reject) => {
        fs.writeFile(path.join(__dirname, './list.json'), JSON.stringify(final), (err: any) => {
            if (err) {
                reject('err')
            } else {
                resolve('ok')
            }
        })
    })
}