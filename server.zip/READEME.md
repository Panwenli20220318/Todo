### 如何启动
- npm i
- npm run dev

### 接口文档

- 【POST】发布待办（http://localhost:3002/api/list/add）
需要的参数：{content: string}
返回值：{msg: stirng, id: string}

- 【GET】获取待办列表 (http://localhost:3002/api/list/getList)

- 【POST】删除待办（http://localhost:3002/api/list/delete）
需要的参数：{id: string}
返回值：{data: string}

- 【POST】完成待办（http://localhost:3002/api/list/done）
需要的参数：{id: string}
返回值：{data: string}

- 【POST】取消完成待办（http://localhost:3002/api/list/cancel）
需要的参数：{id: string}
返回值：{data: string}

