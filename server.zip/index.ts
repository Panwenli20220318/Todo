import * as Koa from 'koa'
import * as KoaCore from 'koa2-cors'
import KoaBody from 'koa-body'
import CONFIG from './config'
import router from './router'

const path = require('path')
const fs = require('fs')

if(!fs.existsSync(path.join(__dirname, 'list.json'))){
    fs.writeFileSync(path.join(__dirname, 'list.json'), JSON.stringify({}))
}

const app = new Koa()
// app.keys = ['forum']
app.use(KoaCore())
app.use(KoaBody({
    multipart: true,
  }))
  .use(router.routes())

app.listen(CONFIG.APP_PORT, () => {
    console.log(`Server running on http://localhost:${CONFIG.APP_PORT}`)
})