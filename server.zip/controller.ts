import { Context } from 'koa'
import {addItem, getList, deleteItem, changeData} from './services'

export async function addData(ctx: Context) {
    const { content } = <Record<string, string>>ctx.request.body
    try {
        const res = await addItem(content)
        if(res.status) {
            ctx.status = 200
            ctx.body = {
                msg: '发布成功',
                id: res.id
            }
        }else {
            ctx.status = 301
            ctx.body = {
                msg: res.msg
            }
        }
        
    }catch(e) {
        ctx.body = {
            code: 0,
            msg: '发布失败'
        }
    }
}

export async function getData(ctx: Context) {
    try {
        const res = await getList()
        ctx.status = 200
        ctx.body = {
            msg: 'ok',
            data: res
        }
    }catch(e) {
        ctx.body = {
            code: 0,
            msg: 'err'
        }
    }
}

export async function deleteData(ctx: Context) {
    const {id} = ctx.request.body
    try {
        const res = await deleteItem(id)
        ctx.status = 200
        ctx.body = {
            data: res
        }
    }catch(e) {
        ctx.body = {
            code: 0,
            msg: e
        }
    }
}

export async function changeDone(ctx: Context) {
    const {id} = ctx.request.body
    try {
        const res = await changeData(id)
        ctx.status = 200
        ctx.body = {
            data: res
        }
    }catch(e) {
        ctx.body = {
            code: 0,
            msg: e
        }
    }
}