import * as Router from 'koa-router'
import { addData, getData, deleteData, changeDone } from './controller'

const router = new Router({ prefix: '/api/list' })

//发布待办
router.post('/add', addData)

//获取待办列表
router.get('/getList', getData)

//删除待办
router.post('/delete', deleteData)

//完成待办
router.post('/done', changeDone)

//取消完成
router.post('/cancel', changeDone)
export default router
